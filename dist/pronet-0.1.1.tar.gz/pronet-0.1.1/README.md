 pronet

`pronet` is a Python library for fetching protein interactions from STRING database, 
building protein networks, visualizing them, and generating reports.

1- Installation

```bash
pip install pronet

2-  Usage

Here is a simple example of how to use pronet: 
from pronet import get_string_interactions, build_network, generate_report

proteins = ["BRCA1", "MDM2", "EGFR"]
data = get_string_interactions(proteins)
G = build_network(data, proteins, show_plot=True, layout="circular")
generate_report(G, proteins, data, save_path="protein_report.txt")

3-  Requirements

Python >= 3.8

requests

networkx

matplotlib
 
4- Features

Fetch interactions for a list of proteins using STRING API.

Build and visualize protein interaction networks using NetworkX and Matplotlib.

Generate detailed reports including main proteins, top interactions, and network statistics.

Choose different network layouts: spring, circular, or shell.

License

MIT License

Copyright (c) 2025 Sarah

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
